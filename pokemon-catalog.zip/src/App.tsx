import { useEffect, useState, useRef } from 'react'
import { useFetch } from './hooks/use-fetch';
import './App.css'
import PokemonCard from '@components/PokemonCard.tsx';
import { useIntersectionObserver } from './hooks/use-observer';

type PokemonList = {results: {name: string, url: string}[]}

function App() {
  const [offset, setOffset] = useState(0);
  const { isLoading, data, updateFetch } = useFetch<PokemonList>(`https://pokeapi.co/api/v2/pokemon?limit=30&offset=${offset}`)
  const [pokemonList, setPokemonList] = useState<PokemonList>(data);
  const loadingRef = useRef<HTMLDivElement>(null)
  const isOnScreen = useIntersectionObserver(loadingRef)

  useEffect(() => {
    console.log(offset);
    if (offset > 0) updateFetch(`https://pokeapi.co/api/v2/pokemon?limit=30&offset=${offset}`)
  }, [offset])

  useEffect(() => {
    console.log(pokemonList, data);
    if (data && offset > 0) setPokemonList((pokemonList) => ({results: [...pokemonList?.results ?? [], ...data.results]}))
  }, [data, offset])

  useEffect(() => {
    if (isOnScreen) {
      setOffset((offset) => offset + 30)
    }
  }, [isOnScreen])

  return (
    <>
    <div className="grid grid-cols-3 gap-14 min-h-screen">
      { pokemonList?.results.map((pokemon, index) => {
        return <PokemonCard key={index} url={pokemon.url}></PokemonCard>
      }) }
    </div>
    <div ref={loadingRef} className="">loading...</div>
    </>
  )
}

export default App
