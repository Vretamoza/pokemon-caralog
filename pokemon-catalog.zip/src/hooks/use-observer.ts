import { useRef, useState, useEffect, RefObject } from "react"

export function useIntersectionObserver(element: RefObject<HTMLElement>) {
    const observerRef = useRef<IntersectionObserver | null>(null)
    const [isOnScreen, setIsOnScreen] = useState(false)

    useEffect(() => {
        observerRef.current = new IntersectionObserver(([entry]) => {
            setIsOnScreen(entry.isIntersecting)
        }, {threshold: 0.5})
    }, [])

    useEffect(() => {
        observerRef.current?.observe(element.current!)
        return () => {
            observerRef.current?.disconnect()
        }
    }, [element])

    return isOnScreen
}